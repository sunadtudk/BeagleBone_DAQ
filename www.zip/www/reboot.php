<?php 
$output = shell_exec('sudo reboot');
echo "<pre>$output</pre>";
echo "REBOOTING!!!! 3 min.and we are back!"; ?>
