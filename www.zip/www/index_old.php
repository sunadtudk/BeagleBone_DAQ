THIS WILL REBOOT Beaglebone...DON'T PANIC!
<FORM METHOD="LINK" ACTION="reboot.php">
 <INPUT TYPE="submit" VALUE="Reboot Beagle Bone(PANIC!)">
 </FORM>

<FORM METHOD="LINK" ACTION="restartserial.php">
 <INPUT TYPE="submit" VALUE="Restart Serial Interface">
 </FORM>

<FORM METHOD="LINK" ACTION="watchdog.php">
 <INPUT TYPE="submit" VALUE="Force Watch Dog run">
 </FORM>

<hr>
<FORM METHOD="LINK" ACTION="test.php">
 <INPUT TYPE="submit" VALUE="Database Running test(BB)">
 </FORM>

<FORM METHOD="LINK" ACTION="test2.php">
 <INPUT TYPE="submit" VALUE="Database Running test(Server)">
 </FORM>

<FORM METHOD="LINK" ACTION="test3.php">
 <INPUT TYPE="submit" VALUE="Netstats on Beaglebone">
 </FORM>

<hr>

<FORM METHOD="LINK" ACTION="beaglebone.txt">
 <INPUT TYPE="submit" VALUE="BB Serial-log (UTC time)">
 </FORM>

<FORM METHOD="LINK" ACTION="/log/index.php">
 <INPUT TYPE="submit" VALUE="BB-logs(OLD .gz packed)">
 </FORM>

<FORM METHOD="LINK" ACTION="debug.txt">
 <INPUT TYPE="submit" VALUE="BB-logs(RAW Serial)">
 </FORM>

<FORM METHOD="LINK" ACTION="lastdate.txt">
 <INPUT TYPE="submit" VALUE="BB WatchDog date-log">
 </FORM>
<br>
Universal Time is now: -2 <br>
Current default time zone: Europe/Copenhagen  <br>
<?php $output = shell_exec('sudo date');
echo "Beaglebone Local time: ";
echo "$output"; ?>

<?php  

$output = shell_exec('sudo uptime');
echo "<pre>$output</pre>";

CPU :
$output = shell_exec('sudo cpufreq-info');
echo "<pre>$output</pre>";

echo "UART info";
$output = shell_exec('sudo cat /sys/kernel/debug/omap_mux/uart*');
echo "<pre>$output</pre>";

echo "GPIO:"; $output = shell_exec('sudo cat /sys/kernel/debug/gpio');
echo "<pre>$output</pre>";

echo "Space on Disk:"; $output = shell_exec('sudo df');
echo "<pre>$output</pre>";

echo "What services is runnning?"; $output = shell_exec('sudo netstat -tna');
echo "<pre>$output</pre>";

echo "Whats running?(PS)"; $output = shell_exec('sudo ps -aux');
echo "<pre>$output</pre>";

?>
