<?php
$output = shell_exec("whoami");
echo $output;
?>
