VMware Server MySQL <br>
<br>
<?php
    mysql_connect("192.168.1.4", "fotonik", "fotonik");
    $array = explode("  ", mysql_stat());
    foreach ($array as $value){
        echo $value . "<br />";
    }
?>
