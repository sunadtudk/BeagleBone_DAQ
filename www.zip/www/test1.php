<?php
$dbhost = '192.168.1.4:3306';
$dbuser = 'root';
$dbpass = 'masterkey';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
$sql = 'SELECT Telitnr ,Netnr ,BBT ,T ,A ,B ,C ,D ,E ,F ,G ,H ,I ,J ,K FROM test';

mysql_select_db('beaglebone');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
    echo "Telit :{$row['Telitnr']}  <br> ".
         "NetNr: {$row['Netnr']} <br> ".
         "BB Date: {$row['BBT']} <br> ".
         "Submission Date : {$row['T']} <br> ".
         "--------------------------------<br>";
} 
echo "Fetched data successfully\n";
mysql_close($conn);
?>
