BeagleBone MySQL info:<br>
<br>
<?php
    mysql_connect("localhost", "fotonik", "fotonik");
    $array = explode("  ", mysql_stat());
    foreach ($array as $value){
        echo $value . "<br />";
    }
?>
