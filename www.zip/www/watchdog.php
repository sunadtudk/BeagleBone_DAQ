<?php

echo "Force Running WatchDog....(Try Serial Restart if nothing happen)";
$output = shell_exec('sudo /etc/cron.hourly/watchdog.sh');
echo "<pre>$output</pre>";

?>
