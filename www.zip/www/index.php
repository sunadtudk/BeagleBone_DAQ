<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<title>DAQ system @ Fotonik-Ris�</title>

<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<link rel="stylesheet" type="text/css" href="main.css">

</head>

<body>

<table class="Global" cellpadding="0" cellspacing="0" border="0">

<!-- ============ Logo ============== -->
<tr><td height="30" colspan="2"><div class="Header_Text">FOTONIK DAQ system</div></td></tr>

<tr><td height="150" colspan="2">

<!-- ============ Header Image ============== -->
<table class="Header_Image" cellspacing="0" border="0"><tr>
<td width="100%" align="left">&nbsp;</td>
</tr></table>

</td></tr>

<!-- ============ COLUMNS SECTION ============== -->
<tr>

<!-- ============ Menu Column ============== -->
<td class="MenuColTD" align="center">

<!-- ============ Site Menu ============== -->

<div class="Menu">


<FORM METHOD="LINK" ACTION="reboot.php">
 <INPUT TYPE="submit" VALUE="Reboot Beagle Bone(PANIC!)">
 </FORM>

<FORM METHOD="LINK" ACTION="restartserial.php">
 <INPUT TYPE="submit" VALUE="Restart Serial Interface">
 </FORM>

<FORM METHOD="LINK" ACTION="watchdog.php">
 <INPUT TYPE="submit" VALUE="Force Watch Dog run">
 </FORM>

<FORM METHOD="LINK" ACTION="resettelit.php">
 <INPUT TYPE="submit" VALUE="Send Reset to Telit">
 </FORM>


<hr>
<FORM METHOD="LINK" ACTION="test.php">
 <INPUT TYPE="submit" VALUE="Database Running test(BB)">
 </FORM>

<FORM METHOD="LINK" ACTION="test2.php">
 <INPUT TYPE="submit" VALUE="Database Running test(Server)">
 </FORM>

<FORM METHOD="LINK" ACTION="test3.php">
 <INPUT TYPE="submit" VALUE="Netstats on Beaglebone">
 </FORM>

<hr>

<FORM METHOD="LINK" ACTION="beaglebone.txt">
 <INPUT TYPE="submit" VALUE="BB Serial-log (UTC time)">
 </FORM>

<FORM METHOD="LINK" ACTION="/log/index.php">
 <INPUT TYPE="submit" VALUE="BB-logs(OLD .gz packed)">
 </FORM>

<FORM METHOD="LINK" ACTION="debug.txt">
 <INPUT TYPE="submit" VALUE="BB-logs(RAW Serial)">
 </FORM>

<FORM METHOD="LINK" ACTION="lastdate.txt">
 <INPUT TYPE="submit" VALUE="BB WatchDog date-log">
 </FORM> 

</div>

</td>


<!-- ============ Content Column ============== -->
<td class="Content">

<!-- ============ Page Heading ============== -->
<h1 class="HeadingStyle">STATUS on BB server:</h1>

<!-- ============ Begin Content ============== -->
Universal Time is now: -2 <br>
Current default time zone: Europe/Copenhagen  <br>

<?php $output = shell_exec('sudo date');

echo "Beaglebone Local time: ";

echo "$output"; ?>



<?php  
$output = shell_exec('sudo cpufreq-info');

echo "<pre>$output</pre>";


echo "UART info";

$output = shell_exec('sudo cat /sys/kernel/debug/omap_mux/uart*');

echo "<pre>$output</pre>";

echo "GPIO:"; 
$output = shell_exec('sudo cat /sys/kernel/debug/gpio');

echo "<pre>$output</pre>";

echo "Space on Disk:"; 
$output = shell_exec('sudo df');

echo "<pre>$output</pre>";



echo "What services is runnning?"; 
$output = shell_exec('sudo netstat -tna');

echo "<pre>$output</pre>";


echo "Whats running?(PS)"; 

$output = shell_exec('sudo ps -aux');

echo "<pre>$output</pre>";

?> 

<!-- ============ End Content ============== -->
</td>


</tr>

<!-- ============ Footer ============== -->
<tr><td colspan="2" class="Footer">

<div class="FooterWrap">

</div>

</td></tr></table>
</body>

</html>
