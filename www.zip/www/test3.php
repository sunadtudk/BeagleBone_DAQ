Beaglebone Net Stat info:<br>
<br>
<?php
$output = shell_exec('sudo netstat -s');
echo "<pre>$output</pre>";   
?>
