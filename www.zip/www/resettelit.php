<?php
$output = shell_exec('echo "high" > /sys/class/gpio/gpio32/direction '); 
$output = shell_exec('echo "low" > /sys/class/gpio/gpio32/direction');
$output = shell_exec('echo "low" > /sys/class/gpio/gpio33/direction');
$output = shell_exec('echo "low" > /sys/class/gpio/gpio34/direction');
$output = shell_exec('echo "in" > /sys/class/gpio/gpio34/direction');
$output = shell_exec('echo "low" > /sys/class/gpio/gpio35/direction ');
$output = shell_exec('echo "low" > /sys/class/gpio/gpio36/direction');
$output = shell_exec('echo "in" > /sys/class/gpio/gpio36/direction ');
$output = shell_exec('echo "high" > /sys/class/gpio/gpio32/direction');
$output = shell_exec('echo 20 > /sys/kernel/debug/omap_mux/uart0_rxd');
$output = shell_exec('echo 0 > /sys/kernel/debug/omap_mux/uart0_txd');
$output = shell_exec('echo 20 > /sys/kernel/debug/omap_mux/uart1_rxd');
$output = shell_exec('echo 0 > /sys/kernel/debug/omap_mux/uart1_txd');
echo "Reseting Telit on Beaglebone(Controller)!"; ?>

