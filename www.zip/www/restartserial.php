<?php

echo "Restart Serial Interface.. Back in 2 min...";
$output = shell_exec('sudo /etc/init.d/serialrestart.sh');
echo "<pre>$output</pre>";

?>
